<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barely Human | Performance Enhancing Clothing | Revivent Yourself </title>
    <link rel="stylesheet" href="./styles/style.css">
    <link rel="stylesheet" href="./fonts/font.css">
</head>

<body>
    <?php   

    $username = 'barelyhu_jeff';
    $password = 'jeffCEO80!';

    if(isset($_POST['submit'])){
        echo $_POST['name'];

        $conn = mysqli_connect("ip", $username, $password, "barelyhu_updated");
        $email = htmlentities(mysqli_escape_string($conn,$_POST['email']));
        $name = htmlentities(mysqli_escape_string($conn, $_POST['name']));

        //Need to put this code somewhere else
        if (isset($email) && isset($name)){
            echo 'Yeah boi';
        }
    }

    ?>
    <div id="container">
        <section class="main_section">
            <!-- The video -->
            <div class="video_wrapper">
                <video id="myVideo" autoplay loop muted>
                    <source src="./assets/images/bg.mp4" type="video/mp4">
                </video>
            </div>

            <div class="landing_wrapper">
                <div class="top_section">
                    <div class="logo">
                        <img src="assets/icons/b.svg" />
                    </div>

                    <div class="landing_message">
                        <span> COMING SOON</span>
                    </div>
                </div>


                <div class="stay_updated_wrapper">
                    <div class="div_updated_outer">
                        <div class="first_section">
                            <span>STAY UPDATED</span>
                        </div>
                        <div class="second_section">
                            <form action="./index.php" method="POST">
                                <input name="name" placeholder="Your Name" type="text" />
                                <input name="email" placeholder="johndoe@gmail.com" type="email" />
                                <input  name="submit" class="submit_button" type="submit" value="JOIN NOW" />
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </div>
</body>
</html>

<!--            <section class="landing">
            </section>

            <section class="landing_message">
                <p class="landing_heading"> <b>LOREM </b> INSPRUM DACOTA</p>
                <p>consectetur adipiscing elit. Phasellus malesuada dapibus sodales. Ut tellus quam, egestas nec pharetra id, porta ac purus. Nulla congue mauris at est mattis</p>

                <button> SHOP NOW</button>
            </section>-->